(function() {
  var button, buttonStyles, materialIcons;

  materialIcons = '<link href="css/icon.family=Material+Icons.css" rel="stylesheet">';

  buttonStyles = '<link href="css/vLmRVp.css" rel="stylesheet">';

  button = '<a href="../" class="at-button"><i class="material-icons">link</i></a>';

  document.body.innerHTML += materialIcons + buttonStyles + button;

}).call(this);